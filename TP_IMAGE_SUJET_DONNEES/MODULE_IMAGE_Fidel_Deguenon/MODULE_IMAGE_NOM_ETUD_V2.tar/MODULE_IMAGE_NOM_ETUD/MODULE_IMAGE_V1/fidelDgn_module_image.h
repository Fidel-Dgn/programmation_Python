#ifndef MODULE_IMAGE_H_INCLUS     /*--  Inclusion conditionnelle --> si pas déjà inclus           */
#define MODULE_IMAGE_H_INCLUS     /*--  alors créer la constante symbolique MODULE_IMAGE_H_INCLUS */

/* AUTEUR : Fidel DEGUENON                       */
/* DATE CREATION : 05/11/2026                      */
/*-------------------------------------------------*/

/* DECLARATIONS DES FONCTIONS */

void test_prog(void);
int afficher_image_codee(int n);

#endif
