#include <stdio.h>
#include <stdlib.h>

#include "fidelDgn_module_image.h"

/* AUTEUR : Fidel Deguenon                       */
/* DATE CREATION :05/11/2026                      */
/*-------------------------------------------------*/

/* PROGRAMME DE TEST de Fidel_MODULE_IMAGE */
int n ;
int main(void)
{
	/* séquence de test des fonction de Fidel_MODULE_IMAGE */
	printf("DEBUT DE TEST MODULE \n");

	test_prog();
	
	printf("DEBUT DE TEST MODULE \n");


	if(scanf("%d",&n)!=1){

		fprintf(stderr,"Erreur : fichier niveau incorrect...");
		return -1;
	}
	printf("\nTrace: test du niveau avec la valeur %d\n",n);
	afficher_image_codee(n);
	
	return EXIT_SUCCESS;   /*-- valeur de retour = succès exécution défini dans stdlib.h */
	
}
