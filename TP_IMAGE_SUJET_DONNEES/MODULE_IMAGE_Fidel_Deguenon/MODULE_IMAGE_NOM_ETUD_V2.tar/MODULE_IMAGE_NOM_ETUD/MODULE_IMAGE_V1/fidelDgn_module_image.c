#include <stdio.h>
#include <stdlib.h>
#include "fidelDgn_module_image.h"


/* AUTEUR : Fidel Deguenon                       */
/* DATE CREATION : 05/11/2026                      */
/*-------------------------------------------------*/

/* DEFINITIONS DES FONCTIONS déclarées dans le .h */

void test_prog(void)
{ 	
	printf("TEST DU MODULE : Fidel_MODULE_IMAGE\n");
	
}

int afficher_image_codee(int n)
{
        int sueil,w,h,p,t,y,i;
        if(n<1 || n>256){
		fprintf(stderr,"Erreur: le niveau de gris n'est pas correcte\n");
                return -1;
        }
        if((n&(n-1))!=0){
		fprintf(stderr,"Erreur: le niveau n'est pas une puissance de 2\n");
                return 0;
        }

        sueil = 255/n;/*seuil de quantification*/
        if(scanf("%d %d",&w,&h)!=2 || w<=0 || h<=0){
		fprintf(stderr,"Erreur: mauvais entete du fichier");
                return -1;
        }
        printf("%d       %d\n",w,h);

        for (y = 0; y < h*w; y++){

               
                if (scanf("%d",&p)!=1 || p<0 || p>255) {
			fprintf(stderr,"Erreur: valeur pixel incorrecte");
                return -1;
            	}
                for(i=1;i<=n;i++){
                        if(p<i*sueil){
                                p=i-1;
                                break;
                        }
                }

                printf("%d",p);
                t=y+1;
                if(t%(w)==0){
                        printf("\n");

                }else{
                        if(p<9){
                                printf("       ");
                        }

                        if(p>9 && p<100){
                                 printf("      ");
                        }

                        if(p>99 && p<=256){
                                 printf("     ");
                        }
                }
		


        }
	return 1;

}	
