#ifndef MODULE_IMAGE_H_INCLUS     /*--  Inclusion conditionnelle --> si pas déjà inclus           */
#define MODULE_IMAGE_H_INCLUS     /*--  alors créer la constante symbolique MODULE_IMAGE_H_INCLUS */
#define  NB_MAX 16
/* AUTEUR : Fidel DEGUENON                       */
/* DATE CREATION : 05/11/2026                      */
/*-------------------------------------------------*/
extern int IMAGE[NB_MAX][NB_MAX];
/* DECLARATIONS DES FONCTIONS */

void test_prog(void);
int afficher_image_codee(int n);
int lire_image(int ligne, int colonne);
void  afficher_image_codee_bis(int n, int ligne, int colonne);
#endif
