#include <stdio.h>
#include <stdlib.h>

#include "fidelDgn_module_image.h"

/* AUTEUR : Fidel Deguenon                       */
/* DATE CREATION :05/11/2026                      */
/*-------------------------------------------------*/

/* PROGRAMME DE TEST de Fidel_MODULE_IMAGE */
int niv,c,p,n,ligne,colonne,i,j;
int main(void)
{
	/* séquence de test des fonction de Fidel_MODULE_IMAGE */
	printf("DEBUT DE TEST MODULE \n");

	test_prog();
	
	printf("DEBUT DE TEST MODULE \n");


        if(scanf("%d %d",&ligne,&colonne)!=2 || ligne<=0 || colonne<=0 || ligne>NB_MAX || colonne>NB_MAX){
                fprintf(stderr,"Erreur : Les dimensions de l'image sont incorrectes ou fichier image corrompu...\n");
        	return -1;
        }
        niv = 256;
	

	lire_image(ligne,colonne);
        printf("=== Image originale ===\n");
        for (i = 0; i < ligne; i++) {
                for (j = 0; j < colonne; j++) {
                printf("%-8d", IMAGE[i][j]);
                }
                printf("\n");
        }
	
        printf("\n=== 38) image_miroir ===\n");
        image_miroir(ligne, colonne);

        printf("\n=== 39) rotation_image 90 ===\n");
        rotation_image(90, colonne, ligne);

        printf("\n=== 39) rotation_image 180 ===\n");
        rotation_image(180, colonne, ligne);

        printf("\n=== 39) rotation_image 45 (cas d'erreur) ===\n");
        rotation_image(45, colonne, ligne);

        printf("\n=== 40) histogramme ===\n");
        histogramme(ligne, colonne, niv);





	/*
	if(scanf("%d",&n)!=1){
		fprintf(stderr,"Erreur : fichier niveau incorrect...");
		return -1;
	}

	if(n<1 || n>256){
		fprintf(stderr,"Erreur: le niveau n'est pas compris entre 1 et 256...");
                return -1;
        }

        if((n&(n-1))!=0){
		fprintf(stderr,"Erreur : le niveau n'est pas une puissance de 2...\n");
                return 0;
        }

	printf("\nTrace: test du niveau avec la valeur %d\n",n);
	
	
        if(scanf("%d",&c)!=1){
                fprintf(stderr,"Erreur : fichier typeAfficheImage incorrect...\n");
                return -1;
        }

	if(c==1){
		printf("Teste de afficher_image_codee\n");
                afficher_image_codee(n);
        }
	if(c==2){
		printf("Teste de afficher_image_codee_bis\n");
		if(scanf("%d %d",&ligne,&colonne)!=2 || ligne<=0 || colonne<=0 || ligne>NB_MAX || colonne>NB_MAX){
                	fprintf(stderr,"Erreur : Les dimensions de l'image sont incorrectes ou fichier image corrompu...\n");
			return -1;
        	}
		lire_image(ligne,colonne);
        	afficher_image_codee_bis(n,ligne,colonne);

	}*/




	/* pout Tester lire image 
	for(i=0;i<ligne;i++){
                for(j=0;j<colonne;j++){
                        
                        p=IMAGE[i][j];
                        printf("%d",p);
                        
                        if(j==colonne-1){
                                printf("\n");

                        }else{
                                if(p<9){
                                        printf("       ");
                                }

                                if(p>9 && p<100){
                                        printf("      ");
                                }

                                if(p>99 && p<=256){
                                        printf("     ");
                                }
                        }
                }
	}

	printf("\nTrace: test du niveau avec la valeur %d\n",n);
	afficher_image_codee(n);
	*/	
	return EXIT_SUCCESS;   /*-- valeur de retour = succès exécution défini dans stdlib.h */
	
}
