#include <stdio.h>
#include <stdlib.h>
#include "fidelDgn_module_image.h"


/* AUTEUR : Fidel Deguenon                       */
/* DATE CREATION : 05/11/2026                      */
/*-------------------------------------------------*/

/* DEFINITIONS DES FONCTIONS déclarées dans le .h */
int IMAGE[NB_MAX][NB_MAX];
void test_prog(void)
{ 	
	printf("TEST DU MODULE : Fidel_MODULE_IMAGE\n");
	
}

int afficher_image_codee(int n)
{
        int sueil,w,h,p,t,y,i;
        if(n<1 || n>256){
		fprintf(stderr,"Erreur: le niveau de gris n'est pas correcte\n");
                return -1;
        }
        if((n&(n-1))!=0){
		fprintf(stderr,"Erreur: le niveau n'est pas une puissance de 2\n");
                return 0;
        }

        sueil = 255/n;/*seuil de quantification*/
        if(scanf("%d %d",&w,&h)!=2 || w<=0 || h<=0){
		fprintf(stderr,"Erreur: mauvais entete du fichier");
                return -1;
        }
        printf("%d       %d\n",w,h);

        for (y = 0; y < h*w; y++){

               
                if (scanf("%d",&p)!=1 || p<0 || p>255) {
			fprintf(stderr,"Erreur: valeur pixel incorrecte");
                return -1;
            	}
                for(i=1;i<=n;i++){
                        if(p<i*sueil){
                                p=i-1;
                                break;
                        }
                }

                printf("%d",p);
                t=y+1;
                if(t%(w)==0){
                        printf("\n");

                }else{
                        if(p<9){
                                printf("       ");
                        }

                        if(p>9 && p<100){
                                 printf("      ");
                        }

                        if(p>99 && p<=256){
                                 printf("     ");
                        }
                }
		


        }
	return 1;

}	

int lire_image(int ligne, int colonne){
        int pixel,i,j,r; 
        for(i=0;i<ligne;i++){
                for(j=0;j<colonne;j++){
                        if(scanf("%d",&pixel)!=1 || pixel<0 || pixel>255){
                                fprintf(stderr,"Erreur: Valeur de pixel incorrecte ou fichier image corrompu\n");
                                r=0;
                        }
                        IMAGE[i][j]=pixel;
                        r=1;
                }
        }
	return r;
}


void  afficher_image_codee_bis(int n, int ligne, int colonne){
        int p,i,j,k;

        int sueil = 255/n;/*seuil de quantification*/
        printf("%d       %d\n",ligne,colonne);

        for (i = 0; i < ligne; i++){
                for(j=0;j<colonne;j++){

                        p=IMAGE[i][j];
                        for(k=1;k<=n;k++){
                                if(p<k*sueil){
                                        p=k-1;
                                        break;
                                }
                        }

                        printf("%d",p);

                        if(j==colonne-1){
                                printf("\n");

                        }else{
                                if(p<9){
                                        printf("       ");
                                }

                                if(p>9 && p<100){
                                        printf("      ");
                                }

                                if(p>99 && p<=256){
                                        printf("     ");
                                }
                        }
                }
        }


}


void image_miroir(int ligne,int colonne)
{
        int i, j,p;

        printf("%d       %d\n",ligne,colonne);
        for (i = 0; i < ligne; i++) {
                for (j = colonne - 1; j >= 0; j--) {
                        p=IMAGE[i][j];
                        
                        printf("%d",p);

                        if(j==colonne-1){
                                printf("\n");

                        }else{
                                if(p<9){
                                        printf("       ");
                                        }

                                if(p>9 && p<100){
                                        printf("      ");
                                }

                                if(p>99 && p<=256){
                                        printf("     ");
                                }
                        }
                }
 
        }
}


void rotation_image(int angle,int colonne,int ligne)
{
    int i, j,p;

    if (angle == 90) {
        /* nouvelle image : */
        for (j = 0; j < colonne; j++) {
            for (i = ligne - 1; i >= 0; i--) {
                p=IMAGE[i][j];
                printf("%d", p);

                if(i==0){
                                printf("\n");

                        }else{
                                if(p<9){
                                        printf("       ");
                                        }

                                if(p>9 && p<100){
                                        printf("      ");
                                }

                                if(p>99 && p<=256){
                                        printf("     ");
                                }
                        }
            }
        
        }
    }
    else if (angle == 180) {
        for (i = ligne - 1; i >= 0; i--) {
            for (j = colonne - 1; j >= 0; j--) {
                p=IMAGE[i][j];
                printf("%d", p);
                if(j==0){
                                printf("\n");

                        }else{
                                if(p<9){
                                        printf("       ");
                                        }

                                if(p>9 && p<100){
                                        printf("      ");
                                }

                                if(p>99 && p<=256){
                                        printf("     ");
                                }
                        }
            }
            
        }
    }
    else {
        printf("Angle non supporte : %d (utiliser 90 ou 180)\n", angle);
    }
}
void histogramme(int ligne, int colonne,int niv)
{
        int i, j, niveau;
	int *effectif;
	int total;
	total = ligne * colonne;

    	effectif = (int *)calloc(niv, sizeof(int));
    	if (effectif == NULL) {
        	printf("Erreur d'allocation memoire\n");
        	return;
    	}
	
        for (i = 0; i < ligne; i++) {
                for (j = 0; j < colonne; j++) {
                        niveau = IMAGE[i][j];
                        
                        effectif[niveau]++;
                
                }
        }

        printf("Niveau | Frequence (%%)\n");
        for (niveau = 0; niveau < niv; niveau++) {
                if (effectif[niveau] > 0) {   /* n'affiche que les niveaux présents */
                printf("%6d | %6.2f\n", niveau, 100.0 * effectif[niveau] / total);
                }
        }
}
